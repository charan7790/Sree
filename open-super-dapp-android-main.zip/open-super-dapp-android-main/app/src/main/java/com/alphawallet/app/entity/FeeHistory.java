package com.alphawallet.app.entity;

/**
 * Created by JB on 18/12/2021.
 */
public class FeeHistory
{
    public String[] baseFeePerGas;
    public double[] gasUsedRatio;
    public String oldestBlock;
    public String[][] reward;
}
