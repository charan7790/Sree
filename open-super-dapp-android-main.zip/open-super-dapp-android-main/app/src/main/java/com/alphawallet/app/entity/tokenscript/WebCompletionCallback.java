package com.alphawallet.app.entity.tokenscript;

public interface WebCompletionCallback
{
    void enterKeyPressed();
}
