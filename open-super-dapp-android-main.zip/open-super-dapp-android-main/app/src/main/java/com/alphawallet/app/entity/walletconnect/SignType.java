package com.alphawallet.app.entity.walletconnect;

/**
 * Created by JB on 10/09/2020.
 */
public enum SignType
{
    MESSAGE,
    SIGN_TX,
    SEND_TX,
    FAILURE,
    SESSION_REQUEST
}
