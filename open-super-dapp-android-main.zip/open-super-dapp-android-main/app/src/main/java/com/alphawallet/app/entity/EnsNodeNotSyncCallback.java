package com.alphawallet.app.entity;

public interface EnsNodeNotSyncCallback
{
    void onNodeNotSynced();
}
