package com.alphawallet.app.entity;

/**
 * Created by JB on 25/03/2022.
 */
public enum TXSpeed
{
    RAPID,
    FAST,
    STANDARD,
    SLOW,
    CUSTOM
}
