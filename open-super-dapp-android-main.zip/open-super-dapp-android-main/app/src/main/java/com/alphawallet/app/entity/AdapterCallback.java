package com.alphawallet.app.entity;

/**
 * Created by JB on 30/08/2020.
 */
public interface AdapterCallback
{
    void resetRequired();
}
