package com.alphawallet.app.entity.tokendata;

/**
 * Created by JB on 7/01/2022.
 */
public enum TokenGroup
{
    ASSET,
    DEFI,
    GOVERNANCE,
    NFT
}
