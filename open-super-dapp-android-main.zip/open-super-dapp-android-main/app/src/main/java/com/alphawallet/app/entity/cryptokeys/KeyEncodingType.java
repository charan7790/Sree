package com.alphawallet.app.entity.cryptokeys;

/**
 * Created by JB on 16/07/2021.
 */
public enum KeyEncodingType
{
    SEED_PHRASE_KEY,
    KEYSTORE_KEY,
    RAW_HEX_KEY
}
