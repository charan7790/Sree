package com.alphawallet.app.entity.tokenscript;

public interface TokenScriptRenderCallback
{
    void callToJSComplete(String function, String result);
}
