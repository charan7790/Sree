package com.alphawallet.app.entity;

public enum DisplayState
{
    CHOOSE_QUANTITY,
    PICK_TRANSFER_METHOD,
    TRANSFER_USING_LINK,
    TRANSFER_TO_ADDRESS,
    NO_ACTION
}
