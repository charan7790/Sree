package com.alphawallet.app.entity;

/**
 * Created by James on 19/02/2018.
 */

public enum ConfirmationType
{
    ETH,
    ERC20,
    ERC875,
    MARKET,
    WEB3TRANSACTION,
    ERC721,
    TOKENSCRIPT,
    RESEND,
    CANCEL_TX
}