package com.alphawallet.app.entity.cryptokeys;

public class KeyServiceException extends Exception
{
    public KeyServiceException(String message)
    {
        super(message);
    }
}
