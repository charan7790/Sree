package com.alphawallet.app.interact;

/**
 * Created by JB on 16/07/2020.
 */
public interface ActivityDataInteract
{
    void fetchMoreData(long latestDate);
}
