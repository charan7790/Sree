package com.alphawallet.app.entity.tokendata;

/**
 * Created by JB on 22/08/2022.
 */
public enum TokenUpdateType
{
    ACTIVE_SYNC, STORED
}
