package com.alphawallet.app.entity;

/**
 * Created by JB on 11/01/2022.
 */
public enum TokenFilter
{
    ALL,
    ASSETS,
    COLLECTIBLES,
    DEFI,
    GOVERNANCE,
    ATTESTATIONS,
    NO_FILTER
}
