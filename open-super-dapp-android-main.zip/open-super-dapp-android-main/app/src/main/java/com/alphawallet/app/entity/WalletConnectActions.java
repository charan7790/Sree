package com.alphawallet.app.entity;

/**
 * Created by JB on 6/06/2021.
 */
public enum WalletConnectActions
{
    CONNECT, APPROVE, REJECT, DISCONNECT, CLOSE, MSG_PUMP, SWITCH_CHAIN, ADD_CHAIN
}
