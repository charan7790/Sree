package com.alphawallet.app.entity;

/**
 * Created by JB on 11/10/2021.
 */
public enum AddressMode
{
    MODE_ADDRESS, MODE_POS, MODE_CONTRACT
}
