package com.alphawallet.app.entity;

/**
 * Created by JB on 20/05/2021.
 */
public class CovalentToken
{
    int contract_decimals;
    String contract_name;
    String contract_ticker_symbol;
    String contract_address;
    String supports_erc;
    String logo_url;
    String balance;
    String quote_rate;
    String quote;
    String nft_data;
}
