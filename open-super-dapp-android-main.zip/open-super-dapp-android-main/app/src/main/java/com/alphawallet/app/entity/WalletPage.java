package com.alphawallet.app.entity;

/**
 * Created by JB on 26/06/2020.
 */
public enum WalletPage
{
    WALLET, ACTIVITY, DAPP_BROWSER, MESSENGER, SETTINGS
}
