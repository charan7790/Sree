package com.alphawallet.app.entity;

/**
 * Created by JB on 16/01/2021.
 */
public interface ActionSheetInterface
{
    void lockDragging(boolean shouldLock);
    void fullExpand();
}
