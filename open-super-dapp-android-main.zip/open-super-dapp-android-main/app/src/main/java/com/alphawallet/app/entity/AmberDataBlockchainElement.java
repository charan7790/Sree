package com.alphawallet.app.entity;

public class AmberDataBlockchainElement
{
    public String blockchainId;
    public String name;
    public String slug;
    public String symbol;
    public String icon;
}
