The lib project contains TokenScript handling code common to all of AlphaWallet Android, the binary utilities, its web backend (currently limited in functionality - mostly it only works to render a token or a magic-link, which is the link format of an attestation).


We plan to move this project to a JavaScript-based library instead. 
