package com.alphawallet.token.entity;

/**
 * Created by JB on 21/05/2020.
 */
public class FilterLogicElement
{
    int type;
}
