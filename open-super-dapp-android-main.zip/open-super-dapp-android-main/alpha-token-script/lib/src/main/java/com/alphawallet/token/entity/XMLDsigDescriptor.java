package com.alphawallet.token.entity;

public class XMLDsigDescriptor
{
    public String result;
    public String subject;
    public String keyName;
    public String keyType;
    public String issuer;
    public SigReturnType type;
    public String certificateName = null;
}
