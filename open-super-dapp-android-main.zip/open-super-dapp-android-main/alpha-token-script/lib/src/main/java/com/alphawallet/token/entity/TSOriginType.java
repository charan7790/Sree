package com.alphawallet.token.entity;

/**
 * Created by JB on 27/07/2020.
 */
public enum TSOriginType
{
    Contract,
    Event
}
