package com.alphawallet.token.entity;

public class ChainSpec
{
    public String name;
    public long chainId;
    public String urlPrefix;
}
