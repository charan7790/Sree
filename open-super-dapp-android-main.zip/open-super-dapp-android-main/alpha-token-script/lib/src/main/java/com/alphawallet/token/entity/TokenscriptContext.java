package com.alphawallet.token.entity;

/**
 * Created by James on 23/05/2019.
 * Stormbird in Sydney
 */
public class TokenscriptContext
{
    public ContractAddress cAddr; // holding contract of primary token
    public AttributeInterface attrInterface;
}
