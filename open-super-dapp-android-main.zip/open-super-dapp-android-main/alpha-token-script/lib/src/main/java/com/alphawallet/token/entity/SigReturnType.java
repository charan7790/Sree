package com.alphawallet.token.entity;

public enum SigReturnType
{
    NO_TOKENSCRIPT,
    DEBUG_NO_SIGNATURE,
    DEBUG_SIGNATURE_INVALID,
    DEBUG_SIGNATURE_PASS,
    NO_SIGNATURE,
    SIGNATURE_INVALID,
    SIGNATURE_PASS
}
