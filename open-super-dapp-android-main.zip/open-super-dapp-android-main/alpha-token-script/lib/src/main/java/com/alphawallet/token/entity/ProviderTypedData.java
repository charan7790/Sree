package com.alphawallet.token.entity;

/**
 * Created by JB on 27/08/2020.
 */
public class ProviderTypedData
{
    public String name;
    public String type;
    public Object value;
}
