package com.alphawallet.token.entity;

/**
 * Created by James on 29/04/2019.
 * Stormbird in Sydney
 */
public enum TokenScriptParseType
{
    tsName, tsContract, tsOrigins, tsCards, tsTokenCard, tsAction, tsViewIconified, tsView, tsAttributeType,
    tsTransaction, tsAttributeTypes, tsToken, ts
}
