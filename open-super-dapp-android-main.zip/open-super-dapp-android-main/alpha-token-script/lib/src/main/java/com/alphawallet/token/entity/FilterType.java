package com.alphawallet.token.entity;

/**
 * Created by JB on 21/05/2020.
 */
public enum FilterType
{
    AND, OR, NOT, GREATER_THAN_OR_EQUAL, LESS_THAN_OR_EQUAL_TO, GREATER_THAN, LESS_THAN, EQUAL, VALUE, ATTRIBUTE, START_BRACE, END_BRACE
}