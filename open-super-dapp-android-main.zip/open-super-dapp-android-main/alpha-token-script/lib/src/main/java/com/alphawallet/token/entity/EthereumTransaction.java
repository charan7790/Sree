package com.alphawallet.token.entity;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by James on 28/05/2019.
 * Stormbird in Sydney
 */
public class EthereumTransaction
{
    public Map<String, TokenscriptElement> args = new HashMap<>();
}
