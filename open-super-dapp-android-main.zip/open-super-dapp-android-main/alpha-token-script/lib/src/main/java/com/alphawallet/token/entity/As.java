package com.alphawallet.token.entity;

/**
 * Created by James on 30/07/2019.
 * Stormbird in Sydney
 */
public enum As {  // always assume big endian
    UTF8, Unsigned, Signed, Mapping, Boolean, UnsignedInput, TokenId, Bytes, e18, e8, e6, e4, e3, e2, Address
}
